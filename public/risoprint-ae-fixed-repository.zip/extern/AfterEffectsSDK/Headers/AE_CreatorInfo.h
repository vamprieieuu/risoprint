/*******************************************************************/
/*                                                                 */
/*                      ADOBE CONFIDENTIAL                         */
/*                   _ _ _ _ _ _ _ _ _ _ _ _ _                     */
/*                                                                 */
/* Copyright 2007 Adobe Systems Incorporated                       */
/* All Rights Reserved.                                            */
/*                                                                 */
/* NOTICE:  All information contained herein is, and remains the   */
/* property of Adobe Systems Incorporated and its suppliers, if    */
/* any.  The intellectual and technical concepts contained         */
/* herein are proprietary to Adobe Systems Incorporated and its    */
/* suppliers and may be covered by U.S. and Foreign Patents,       */
/* patents in process, and are protected by trade secret or        */
/* copyright law.  Dissemination of this information or            */
/* reproduction of this material is strictly forbidden unless      */
/* prior written permission is obtained from Adobe Systems         */
/* Incorporated.                                                   */
/*                                                                 */
/*******************************************************************/


/*	If you'd like After Effects to open files created by your application
	IN your application, embed this structure in that file.
	
	Data must be in Motorola byte order.
	
	Your application must then respond to the appleEvent (mac) or the
	command line flags (win) that are specified in the structure.
*/

#define ADBE_CREATOR_ATOM_TYPE 'Cr8r'
#define	CR8R_MAGIC	0xBEEFCAFE

#define	ADBE_CREATOR_ATOM_VERS_MAJOR	1
#define	ADBE_CREATOR_ATOM_VERS_MINOR	0

typedef struct adbe_creator_atom {
	unsigned long		magicLu;			// set to CR8R_MAGIC

	long    			atom_sizeL;			// size of this structure (sizeof(CR8R_CreatorAtom))
	short    			atom_vers_majorS;	// set to ADBE_CREATOR_ATOM_VERS_MAJOR
	short    			atom_vers_minorS;	// set to ADBE_CREATOR_ATOM_VERS_MINOR

	// mac
	unsigned long		creator_codeLu;		// application code on MacOS
	unsigned long 		creator_eventLu;	// invocation appleEvent
			
	// windows
	char    			creator_extAC[16];	// extension allowing registry search to app
	char    			creator_flagAC[16];	// flag passed to app at invocation time

	char    			creator_nameAC[32];	// name of the creator application
} CR8R_CreatorAtom, **CR8R_CreatorAtomHandle;

