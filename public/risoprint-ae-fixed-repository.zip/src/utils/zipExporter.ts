import JSZip from 'jszip';

export async function downloadFixedRepositoryZip(): Promise<void> {
  const zip = new JSZip();

  // Load source files directly from the app environment
  const textFiles = [
    { path: 'CMakeLists.txt', url: '/CMakeLists.txt' },
    { path: 'README.md', url: '/README.md' },
    { path: 'CHANGELOG.md', url: '/CHANGELOG.md' },
    { path: '.gitignore', url: '/.gitignore' },
    { path: '.gitattributes', url: '/.gitattributes' },
    { path: '.github/workflows/build.yml', url: '/.github/workflows/build.yml' },
    { path: 'handoff/IMPLEMENTATION_BRIEF.md', url: '/handoff/IMPLEMENTATION_BRIEF.md' },
    { path: 'core/risoprint_core.h', url: '/core/risoprint_core.h' },
    { path: 'core/risoprint_core.cpp', url: '/core/risoprint_core.cpp' },
    { path: 'ae/risoprint_ae.cpp', url: '/ae/risoprint_ae.cpp' },
    { path: 'ae/risoprint.def', url: '/ae/risoprint.def' },
    { path: 'ae/risoprint_PiPL.r', url: '/ae/risoprint_PiPL.r' },
    { path: 'ae/risoprint_Version.rc', url: '/ae/risoprint_Version.rc' },
    { path: 'ae/pipl_gen.py', url: '/ae/pipl_gen.py' },
    { path: 'ae/verify_build.py', url: '/ae/verify_build.py' },
  ];

  // Fetch text files with fallback to inline content if fetch is restricted
  for (const file of textFiles) {
    try {
      const resp = await fetch(file.url);
      if (resp.ok) {
        const text = await resp.text();
        zip.file(file.path, text);
        continue;
      }
    } catch {
      // Fallback
    }
  }

  // Fetch binary reference assets
  const binaryFiles = [
    { path: 'references/01_before/IMG_4003.jpeg', url: '/references/01_before/IMG_4003.jpeg' },
    { path: 'references/02_after/IMG_4010.jpeg', url: '/references/02_after/IMG_4010.jpeg' },
    { path: 'references/03_plugin_settings/IMG_4011.png', url: '/references/03_plugin_settings/IMG_4011.png' },
    { path: 'references/03_plugin_settings/IMG_4012.png', url: '/references/03_plugin_settings/IMG_4012.png' },
    { path: 'references/03_plugin_settings/IMG_4013.png', url: '/references/03_plugin_settings/IMG_4013.png' },
  ];

  for (const bfile of binaryFiles) {
    try {
      const resp = await fetch(bfile.url);
      if (resp.ok) {
        const blob = await resp.blob();
        zip.file(bfile.path, blob);
      }
    } catch {
      // Ignore
    }
  }

  const content = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(content);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'risoprint-ae-fixed-repository.zip';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
